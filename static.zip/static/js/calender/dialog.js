var dialog = document.getElementById('dialog');
function openDialog() {
    dialog.style.display = "block";
}
function closeDialog() {
    dialog.style.display = "none";
}
